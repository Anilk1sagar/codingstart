var stars = document.getElementById('stars');

function displayStar() {
	stars.style.display = 'block';
	document.body.style.background = '#000';
}

function hideStar() {
	stars.style.display = 'none';
	document.body.style.background = '#3B4757';
}