function paragraph(id)
    {
     $("#"+id+"-para").slideToggle();
    }