$(document).ready(function(){
    $("button.open").click(function(){
    	$("#popup_box").show();
    });
});

$(document).ready(function(){
    $("button.close").click(function(){
    	$("#popup_box").hide();
    });
});
